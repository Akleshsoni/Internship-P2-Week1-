import React, { useState } from 'react';
import { Gavel, Upload, Clock, DollarSign, Tag, BarChart2, Package, Heart, Eye, Timer, Mail, Lock, ArrowRight, User } from 'lucide-react';

function App() {
  const [currentView, setCurrentView] = useState('login');

  const renderContent = () => {
    if (currentView === 'dashboard') {
      return (
        <div className="space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Bids</p>
                  <p className="text-2xl font-semibold text-gray-800">12</p>
                </div>
                <BarChart2 className="w-8 h-8 text-purple-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Items Won</p>
                  <p className="text-2xl font-semibold text-gray-800">8</p>
                </div>
                <Package className="w-8 h-8 text-green-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Watchlist</p>
                  <p className="text-2xl font-semibold text-gray-800">15</p>
                </div>
                <Heart className="w-8 h-8 text-red-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-md p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Total Spent</p>
                  <p className="text-2xl font-semibold text-gray-800">$2,450</p>
                </div>
                <DollarSign className="w-8 h-8 text-blue-500" />
              </div>
            </div>
          </div>

          {/* Active Auctions */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Your Active Auctions</h3>
            <div className="space-y-4">
              {[
                {
                  title: "Vintage Rolex Submariner",
                  currentBid: 12500,
                  timeLeft: "2 days",
                  watchers: 24,
                  image: "https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?auto=format&fit=crop&w=300&q=80"
                },
                {
                  title: "MacBook Pro M1 Max",
                  currentBid: 2100,
                  timeLeft: "5 hours",
                  watchers: 45,
                  image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=300&q=80"
                },
                {
                  title: "Vintage Camera Collection",
                  currentBid: 850,
                  timeLeft: "1 day",
                  watchers: 12,
                  image: "https://images.unsplash.com/photo-1452780212940-6f5c0d14d848?auto=format&fit=crop&w=300&q=80"
                }
              ].map((auction, index) => (
                <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                  <img
                    src={auction.image}
                    alt={auction.title}
                    className="w-20 h-20 object-cover rounded-md"
                  />
                  <div className="flex-1">
                    <h4 className="text-lg font-medium text-gray-800">{auction.title}</h4>
                    <div className="flex items-center space-x-4 mt-2">
                      <span className="flex items-center text-sm text-gray-500">
                        <DollarSign className="w-4 h-4 mr-1" />
                        Current Bid: ${auction.currentBid.toLocaleString()}
                      </span>
                      <span className="flex items-center text-sm text-gray-500">
                        <Timer className="w-4 h-4 mr-1" />
                        {auction.timeLeft} left
                      </span>
                      <span className="flex items-center text-sm text-gray-500">
                        <Eye className="w-4 h-4 mr-1" />
                        {auction.watchers} watching
                      </span>
                    </div>
                  </div>
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Recent Activity</h3>
            <div className="space-y-4">
              {[
                {
                  action: "Outbid",
                  item: "Antique Persian Rug",
                  time: "10 minutes ago",
                  price: "$4,200"
                },
                {
                  action: "Won",
                  item: "Limited Edition Sneakers",
                  time: "2 hours ago",
                  price: "$850"
                },
                {
                  action: "Bid Placed",
                  item: "Art Deco Lamp",
                  time: "5 hours ago",
                  price: "$320"
                }
              ].map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-3 border-b last:border-b-0">
                  <div className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${
                      activity.action === 'Won' ? 'bg-green-500' :
                      activity.action === 'Outbid' ? 'bg-red-500' :
                      'bg-blue-500'
                    }`} />
                    <div>
                      <p className="text-sm font-medium text-gray-800">
                        {activity.action} on {activity.item}
                      </p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                  <span className="text-sm font-medium text-gray-600">{activity.price}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    }

    if (currentView === 'post-auction') {
      return (
        <div className="bg-white rounded-lg shadow-xl p-8">
          <h2 className="text-2xl font-semibold text-gray-800 mb-6">Post New Auction</h2>
          
          <form className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Item Name</label>
              <input
                type="text"
                placeholder="e.g., Vintage Watch"
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <textarea
                rows={4}
                placeholder="Describe your item in detail..."
                className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Starting Bid</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    placeholder="0.00"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-700">Duration (Days)</label>
                <div className="relative">
                  <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="number"
                    min="1"
                    max="30"
                    placeholder="7"
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Category</label>
              <div className="relative">
                <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <select className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all appearance-none">
                  <option value="">Select a category</option>
                  <option value="electronics">Electronics</option>
                  <option value="fashion">Fashion</option>
                  <option value="collectibles">Collectibles</option>
                  <option value="art">Art</option>
                  <option value="jewelry">Jewelry</option>
                  <option value="vehicles">Vehicles</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Images</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-purple-500 transition-colors">
                <Upload className="mx-auto h-12 w-12 text-gray-400" />
                <div className="mt-2">
                  <p className="text-sm text-gray-500">
                    Drag and drop images here, or click to select files
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    (Maximum 5 images, PNG or JPG, up to 5MB each)
                  </p>
                </div>
                <input type="file" className="hidden" multiple accept="image/*" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-3 rounded-md hover:bg-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 flex items-center justify-center gap-2"
            >
              <Gavel className="w-4 h-4" />
              Create Auction
            </button>
          </form>
        </div>
      );
    }

    if (currentView === 'signup') {
      return (
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-2">Create Account</h2>
            <p className="text-gray-600">Join our auction community today</p>
          </div>
          
          <form className="space-y-6">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="John Doe"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  placeholder="you@example.com"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="terms"
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-gray-700">
                I agree to the <button type="button" className="text-purple-600 hover:text-purple-500">Terms</button> and{' '}
                <button type="button" className="text-purple-600 hover:text-purple-500">Privacy Policy</button>
              </label>
            </div>

            <button
              type="submit"
              className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 flex items-center justify-center gap-2"
            >
              Create Account
              <ArrowRight className="w-5 h-5" />
            </button>

            <p className="text-center text-sm text-gray-600">
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => setCurrentView('login')}
                className="font-medium text-purple-600 hover:text-purple-500"
              >
                Log in
              </button>
            </p>
          </form>
        </div>
      );
    }

    // Login view (default)
    return (
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full mx-auto">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">Welcome Back</h2>
          <p className="text-gray-600">Enter your credentials to access your account</p>
        </div>
        
        <form className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="email"
                placeholder="you@example.com"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="password"
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="remember"
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
              />
              <label htmlFor="remember" className="ml-2 block text-sm text-gray-700">
                Remember me
              </label>
            </div>
            <button type="button" className="text-sm font-medium text-purple-600 hover:text-purple-500">
              Forgot password?
            </button>
          </div>

          <button
            type="submit"
            className="w-full bg-purple-600 text-white py-3 rounded-lg hover:bg-purple-700 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 flex items-center justify-center gap-2"
          >
            Login
            <ArrowRight className="w-5 h-5" />
          </button>

          <p className="text-center text-sm text-gray-600">
            Don't have an account?{' '}
            <button
              type="button"
              onClick={() => setCurrentView('signup')}
              className="font-medium text-purple-600 hover:text-purple-500"
            >
              Sign up
            </button>
          </p>
        </form>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 to-blue-500">
      {/* Header */}
      <header className="p-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col items-center space-y-4">
            <h1 className="text-4xl font-bold text-white flex items-center gap-2">
              <Gavel className="w-8 h-8" />
              Auction App
            </h1>
            <nav className="flex gap-6">
              <button
                className={`text-white hover:text-white/80 transition-colors ${currentView === 'login' ? 'border-b-2 border-white' : ''}`}
                onClick={() => setCurrentView('login')}
              >
                Login
              </button>
              <button
                className={`text-white hover:text-white/80 transition-colors ${currentView === 'signup' ? 'border-b-2 border-white' : ''}`}
                onClick={() => setCurrentView('signup')}
              >
                Signup
              </button>
              <button
                className={`text-white hover:text-white/80 transition-colors ${currentView === 'dashboard' ? 'border-b-2 border-white' : ''}`}
                onClick={() => setCurrentView('dashboard')}
              >
                Dashboard
              </button>
              <button
                className={`text-white hover:text-white/80 transition-colors ${currentView === 'post-auction' ? 'border-b-2 border-white' : ''}`}
                onClick={() => setCurrentView('post-auction')}
              >
                Post Auction
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-6">
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="mt-8 text-center pb-8">
        <p className="text-gray-200">© 2024 Auction App. All rights reserved.</p>
        <p className="text-gray-200 mt-2">
          Welcome to the best place to buy and sell items through auctions!
        </p>
      </footer>
    </div>
  );
}

export default App;